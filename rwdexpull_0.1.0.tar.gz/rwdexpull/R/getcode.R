
#' Retrieve a list of ICD codes from a data frame
#' or a csv/txt file with a list of icd code.
#'
#' @param datafile is a data frame with a column contains a
#'        list of ICD codes. Name convention for this column
#'        should start with "icd" and end with string "list"
#'        or "code". Intended for extract a long list of
#'        ICD code, please don't use this for a single code.
#' @param regular is an indicator of the code retrieval method.
#'        If regular is given value 1, then output should return a
#'        string a list with regular expression like "M32|M42";
#'        Other input will return a list of string with delimited
#'        by "," like "'M32','M42'".
#' @importFrom data.table fread
#' @importFrom data.table setDT
#' @return a list of ICD codes which can be used in SQL query.
#' @examples
#' \dontrun{
#' cdlist(data.frame(icd_list = c('M32','M42'),1))
#' }
#' @export
cdlist <- function(datafile,regular){
  # check if missing arguments
  defined <- ls()
  passed <- names(as.list(match.call())[-1])

  if (any(!defined %in% passed)) {
    stop(paste("Missing values for", paste(setdiff(defined, passed), collapse = ", ")))
  }

  #  if (missing(datafile)) {
  #   stop("The file with code list is missing!")
  # }
  requireNamespace("data.table")
  if (is.data.frame(datafile)) df <- setDT(datafile)
  else  df <- fread(datafile)


  icdloc <- grep("(?i)^icd(.*)(list)|(code)$", names(df))
  listn <- unique(df[,..icdloc])

  if (length(listn) < 2) {
      stop("Not intended for a single code...")
    }

  if (regular == 1) {
    icdcodes <- lapply(listn,paste0,'|')
    codelist <- gsub('^c\\(|\\)$|\\\"|\\,','',icdcodes)
    # remove last "|" sign
    codelists <- gsub('\\|$','',codelist)
    pref <- paste0('^',gsub(' ','',codelists))
    x <- gsub('\\|','\\|\\^',pref)
  }
  else {
    icdcode <- gsub('^c\\(|\\)$|\\.','',listn)
    icdcodes <- gsub('\\"',"\\'",icdcode)
    x <- gsub(' ','',icdcodes)
  }
  return(x)
}
