
#' Pull data and conduct basic summary from RWDEx data base
#'
#' @export
cohortpull <- function(){
  appDir <- system.file("pullapp", package = "rwdexpull")
  if (appDir == "") {
    stop("Could not find pullapp. Try re-installing `rwdexpull`.", call. = FALSE)
  }
  shiny::runApp(appDir)
  # shiny::runApp(appDir, display.mode = "normal")
}

