options(shiny.maxRequestSize = 500*1024^2,scipen=999,decimal=3,shiny.error = browser)

server <- function(input, output) {
  # for landingPage
  # redirectPage("index.html",status = 302)
  set.seed(122)
  histdata <- rnorm(250)
  observeEvent(once = TRUE,ignoreNULL = FALSE,
               ignoreInit = FALSE,
               eventExpr = histdata, {
    # event will be called when histdata changes, which only happens once, when it is initially calculated
    showModal(modalDialog(
      # title = "Welcome to cohort pull for RWDEx!",
      div(tags$img(width = 100,height = 100,src = "merck-co.jpg"),
          div(style = "height:30px; font-size:30px;bold;color:#007a73;", "Welcome to RWDEx data explorer!")),
      p(),
      div(style = "height:22px; font-size:22px;bold;color:#007a73;",icon('pagelines'),"Introduction:"),
      p(),
      div(style = "height:20px; font-size:20px;bold;",
          'This App provides point-click tool for data pulling and explonatory analysis.'),
       p(),
      div(style = "height:20px; font-size:20px;bold;",'Please make sure access to databases is granted.'),
      p(),
      div(style = "height:22px; font-size:22px;bold;color:#007a73;",icon('sticky-note'),"Notes to users:"),
       p(),
      div(style = "height:20px; font-size:20px;bold;",'1. File format in csv or txt with variable name start
        with icd end with code.'),
      p(),
      div(style = "height:20px; font-size:20px;bold;",'2. Customized summary with P-values only available when cohort pull is done.')
      ,
      # p(),
      # div(style = "height:22px; font-size:22px;bold;color:#007a73;",icon('video-camera'),"Demo video:"),
      #   tags$video(
      #   src = "data pull.mp4",
      #   type = "video/mp4",
      #   autoplay = TRUE,
      #   muted = TRUE,
      #   playsinline = T,
      #   loop = F,
      #   controls = TRUE,
      #   height = 350,
      #   width = 305,
      #   border = 0),

    ))
  })
  #End landingPage


  # avoid scientific notation
  output$fileflag <- renderUI({
    checkboxInput("fileflag", "Have a code list to upload", T)
  })

  #This function is responsible for loading in the selected file
  filedata <- reactive({
    infile <- input$datafile
    isolate({infile = input$datafile})
     if (is.null(infile)) {
       return(NULL)
    }
    raws <- fread(infile$datapath,stringsAsFactors = F,
                  na.strings = c("",NA,'Not Available','Not available','Not sure','not sure','unknown','Unknown','not available','na','?','No info','no info','refused','Refused','NA','missing','Missing'))
    # setnames(raws,'V1','id')
    # dbWriteTable(con,DBI::Id(schema=redshift_work_space,table="codeflat"),raws, overwrite = TRUE)
    return(unique(raws))
  })


  # pull flag
  output$pull <- renderUI({
    checkboxInput("pullflag", "Prefer data pull directly", FALSE)
  })

  output$choose <- renderUI({
    checkboxInput("chooseflag", "Choose variables for summary?", F)
  })


  # output$cred <- renderUI({
  #   # passwordInput(uid, 'User name:', value = "", width = NULL, placeholder = NULL)
  #   passwordInput(pwd, 'RWDEx access password:', value = "", width = NULL, placeholder = NULL)
  #   # uid=rstudioapi::showPrompt(title = "UserName", message = "RWDEx User Name:",default = "")
  #   # pwd=rstudioapi::askForPassword(prompt = "RWDEx access password:")
  #  })

  # id <- reactive(
  #   {
  #      id=input$user
  #     return(id)
  #
  #   }
  #  )
  #

  observeEvent(input$toTop, {
    js$toTop();
  })

  output$basic <- renderUI({
    df <- filedata()
    if (is.null(df)) return(NULL)
    rows=nrow(df)
    varn = length(unique(names(df)))
    filename = input$datafile$name

        div(style = "height:15px; font-size:15px;bold;italic;color:navy;",
        paste('Your File has ',rows,' rows,',varn,' variables.'))
  })

  output$print <- renderDataTable({
    df <- filedata()
    filename <- input$datafile$name
    if (is.null(df)) return(NULL)
    else
    {df %>% datatable(editable = 'cell', extensions = c("FixedHeader",'Buttons'),
                      caption = paste("Your uploaded file ",filename),
                      options = list(dom = 'BlfrtipB',
                                     # paging=T,
                                     buttons = c('copy', 'csv', 'excel', 'pdf', 'print'),
                                     lengthMenu = list(c(10,25,50,-1),
                                                       c(10,25,50,"All"))))
    }
  })


  bee <- reactive({
    pullopt <- reactive(input$pullflag)
    req(pullopt() == TRUE)
    uid = input$user
    pwd = input$password
    driver = "redshift"
    server = "rwdex-prod-redshift-redshiftcluster-jkm8jit7jdii.cc45eneh17kp.us-east-1.redshift.amazonaws.com"
    database = "chminer"
    con <- DBI::dbConnect(odbc::odbc(),
                          Driver =driver,
                          Server= server,
                          Port = 5439,
                          Database = database,
                          UID = uid,
                          PWD = pwd,
                          sslmode = "allow")

    if (DBI::dbIsValid(con) == TRUE)
      return(list(uid = uid,pwd = pwd))
    else {
      return(NULL)
    }
  })

  output$beevalid <- renderPrint({
    if (is.null(bee())) {
      print("Please check your credentials")
    }
    else {
      print("No error")
    }
  })

  pulled <- reactive(
    {
      df <- filedata()
      req(!is.null(df))
      if (input$pullflag == 'TRUE') {
        # uid = bee()$uid
        # pwd = bee()$pwd
        uid = input$user
        pwd = input$password
      }
      else {
        uid = "songlih"
        pwd = "6@Sob8c3"
      }

      # if (is.null(df)) return(NULL)
      driver = "redshift"
      server = "rwdex-prod-redshift-redshiftcluster-jkm8jit7jdii.cc45eneh17kp.us-east-1.redshift.amazonaws.com"
      database = "chminer"

     con <- DBI::dbConnect(odbc::odbc(),
                            Driver =driver,
                            Server= server,
                            Port = 5439,
                            Database = database,
                            UID = uid,
                            PWD = pwd,
                            sslmode = "allow")

    if (DBI::dbIsValid(con) == TRUE) {
      redshift_work_space= paste0('SAS_work_',uid)
      rawdata <- c('rwdex_raw_premier_version3','rwdex_raw_optum_cdm_raw_version3','rwdex_raw_humana_version3','rwdex_raw_iqvia_ambulatory_emr','rwdex_raw_cprd_version3')
      omopdata <- c('rwdex_omop_premier','rwdex_omop_optum_cdm','rwdex_omop_humana','rwdex_omop_iqvia_ambulatory_emr')
      icdloc <- grep("(?i)^icd(.*)(list)|(code)$", names(df))
      listn <- unique(df[,..icdloc])
      icdcodes <- lapply(listn,paste0,'|')
      codelist <- gsub('^c\\(|\\)$|\\\"|\\,','',icdcodes)
      # remove last "|" sign
      codelists <- gsub('\\|$','',codelist)
      pref <- paste0('^',gsub(' ','',codelists))
      icdcode <- gsub('\\|','\\|\\^',pref)

      library(glue)

      startdate <- reactive(paste0("'",input$dateRange[1],"'"))
      enddate <- reactive(paste0("'",input$dateRange[2],"'"))

      listpull <- glue("create temp table listdx
           as with c1 as(select
           distinct patid, admit_date, diag1,diag2,diag3,diag4,diag5, icd_flag
           from {rawdata[2]}.inpatient_confinement
          where
           (diag1 ~ ('{icdcode}')
            or
            diag2 ~ ('{icdcode}')
            or
            diag3 ~ ('{icdcode}')
            or
            diag4 ~ ('{icdcode}')
            or
            diag5 ~ ('{icdcode}')
            )
           ),
           c2 as(select c1.*,b.race,b.state,b.yrdob,b.gdr_cd
             from c1 left join {rawdata[2]}.member_enrollment b
             on c1.patid = b.patid)

           select patid,race,yrdob,gdr_cd,state,admit_date,diag1,diag2,diag3,diag4,diag5
             from c2
             where admit_date >= cast({startdate()} as date)
            and admit_date <= cast({enddate()} as date)

                       "
      )

      DBI::dbExecute(con, "drop table if exists listdx")
      list1 <- DBI::dbGetQuery(con,listpull)
      cddata <- DBI::dbGetQuery(con,"select distinct patid,race,yrdob as dob,state,
      gdr_cd as gender, admit_date,
      cast(extract(year from admit_date)-yrdob as integer) as age
                                from listdx ")
      setDT(cddata)
      setkey(cddata,patid,admit_date)
      library(gtsummary)
      tabone <- cddata %>% select(race,age,gender)
      tabonep <- tbl_summary(tabone,by = gender) %>% as_tibble()
      setDT(tabonep)
      # table1 <- tbl_summary(trial2)select()print(CreateTableOne(vars = c('state','age','race'),addOverall = T,includeNA = TRUE,data=dfl),showAllLevels = F, nonnormal=nmvar, noSpaces = TRUE)
      # setDT(tabonep)
      attrition <- DBI::dbGetQuery(con,"
                               select 'Total' as name,cast(count(distinct patid) as integer) as count
                               from listdx
                               union
                               select 'Age' as name,cast(count(distinct patid) as integer) as counnt
                               from listdx
                               where cast(extract(year from admit_date)-yrdob as integer) >= 18
                               union
                               select 'Senio' as name,cast(count(distinct patid) as integer) as counnt
                               from listdx
                               where cast(extract(year from admit_date)-yrdob as integer) >= 65
                               ")


      return(
        list(
          ipsamp = cddata,
          ipsum =  tabonep,
          attrition = attrition
        )
      )
    }

  else {
    return(
      list(
        ipsamp = NULL,
        ipsum =  NULL,
        attrition = NULL
      )
    )
  }

    }
  ) # end of reactive
  # connect to redshift

  #The checkbox selector is used to determine whether only show on database
  output$flag <- renderUI({
    checkboxInput("flag", "Show only one RWDEx data", F)
  })

  output$add <- renderUI({
    checkboxInput("add", "Need customized summary", F)
  })

  output$aflag <- renderUI({
    # df <- filedata()
    # if (is.null(df)) return(NULL)
    selectInput("Database", "Selection:",
                c("1.Premier" = 'premier',
                  "2.Optum" = "optum",
                  "3.Humana" = "humana",
                  '4.IQVIA' = 'iqvia',
                  '5.CPRD' = 'cprd'
                ),selected = 'optum')
  })


  output$regflag <- renderUI({
    # df <- filedata()
    # if (is.null(df)) return(NULL)
    radioButtons("Schema", "Selection:",
                 c("1.Raw data" = 'raw',
                   "2.OMOP data" = "omop"
                 ),selected = 'raw')
  })

  # output$ids <- renderUI({
  #   # df <- filedata()
  #   # if (is.null(df)) return(NULL)
  #   rstudioapi::askForPassword("Your user id:")
  # })
  #
  # output$bees <- renderUI({
  #   rstudioapi::askForPassword("Your password for RWDEx:")
  # })
  #

  labtable <- reactive({
    # for OMOP
    start = year(input$dateRange[1])
    end = year(input$dateRange[2])

    if (input$Schema == 'omop') {
      if (input$flag == T) {
        outtab <- omopdata[str_to_lower(Database) == input$Database & year >= start & year <= end,]
      }
      else {
        outtab <- omopdata[year >= start & year <= end,]
      }
      return(outtab)
    }

    # Raw schema
    else if (input$Schema == 'raw'){

      if (input$flag == T)
      {
        rawprnt <- rawdata[(str_to_lower(Database) == input$Database) & year >= start & year <= end,]
      }

      else {
        rawprnt <- rawdata[year >= start & year <= end,]
      }

      return(rawprnt)
    }
  }) # end of reactive


  # output$omop <- renderDataTable(
  #   filename = input$datafile$name
  #   labtable() %>% datatable(extensions = c('FixedColumns',"FixedHeader",'Buttons'),
  #                            caption = Paste("Using code from ",file),
  #                            options = list(dom = 'BlfrtipB',
  #                                           # paging=T,
  #                                           buttons = c('copy', 'csv', 'excel', 'pdf', 'print'),
  #                                           lengthMenu = list(c(10,25,50,-1),
  #                                                             c(10,25,50,"All")))
  #                            )
  # )


  # comparison

  compare <- reactive(
    {
      start = year(input$dateRange[1])
      end = year(input$dateRange[2])
      # rawdata$year <- as.numeric(rawdata$year)

      if (input$flag == T) {
        comp <- compall[input$Database == str_to_lower(Database) & year >= start & year <= end,]
        # rawprnt <- rawdata[input$Database==str_to_lower(Database) & year >= start & year <= end,-'Schema']
        # setkey(rawprnt,Database,year,category,component,long_common_name)
        # setkey(outtab,Database,year,category,component,long_common_name)
        # comp <- rawprnt[outtab]
        # setnames(comp,old=c('patients','Records','i.patients','records'),new=c('Patients_Raw','Records_Raw','Patients_OMOP','Records_OMOP'))
        # numlist=c('Patients_Raw','Records_Raw','Patients_OMOP','Records_OMOP')
        # comp[, (numlist):= lapply(.SD,format,scientific = F),.SDcol=numlist]
      }
      else {
        comp <- compall[year >= start & year <= end,]
        # rawprnt <- rawdata[ year >= start & year <= end,-'Schema']
        #
        # setkey(rawprnt,Database,year,category,component,long_common_name)
        # setkey(outtab,Database,year,category,component,long_common_name)
        # comp <- rawprnt[outtab]
        # setnames(comp,old=c('patients','Records','i.patients','records'),new=c('Patients_Raw','Records_Raw','Patients_OMOP','Records_OMOP'))
        #  numlist=c('Patients_Raw','Records_Raw','Patients_OMOP','Records_OMOP')
        #  comp[, (numlist):= lapply(.SD, as.numeric),.SDcol=numlist]
      }
      return(comp[,.(Database,year,category,component,Patients_Raw,Patients_OMOP,Records_Raw,Records_OMOP,code)])
    })


  output$comp <- renderDT({
    filename = input$datafile$name
    datatable(compare(),extensions = c("FixedHeader",'Buttons'),
              caption = paste("Using code from file ",filename),
              options = list(dom = 'BlfrtipB',
                             # paging=T,
                             buttons = c('copy', 'csv', 'excel', 'pdf', 'print'),
                             lengthMenu = list(c(10,25,50,-1),
                                               c(10,25,50,"All"))
                             # ,
                             # rowCallback=JS("
                             # function(row, data) {
                             #   for (i = 1; i < data.length; i++) {
                             #   $('td:eq('+i+')', row).html(data[i].toString());
                             #   }
                             #   }"
                             # )
              )
    )
  })


  # ipsum <- pulled$ipsum


  output$pulled <- renderDT({
    # pulled <- pulled()
    req(!is.null(pulled()$ipsamp))
    ipsamp <- pulled()$ipsamp
    filename = input$datafile$name

    datatable(ipsamp,extensions = c("FixedHeader",'Buttons'),
              caption = paste("Using code from file ",filename),
              options = list(dom = 'BlfrtipB',
                             # paging=T,
                             buttons = c('csv', 'excel'),
                             lengthMenu = list(c(10,25,50,-1),
                                               c(10,25,50,"All"))

              )
    )
    #                                         ,
    # rowCallback = JS(
    # "function toString(num) {
    #   return (''+ +num).replace(/(-?)(\d*)\.?(\d*)e([+-]\d+)/,
    #                             function(a,b,c,d,e) {
    #                               return e < 0
    #                               ? b + '0.' + Array(1-e-c.length).join(0) + c + d
    #                               : b + c + d + Array(e-d.length+1).join(0);
    #                             });
    # }",
    #   "function(row, data) {",
    #   "for (i = 1; i < data.length; i++) {",
    #   "$('td:eq('+i+')', row).html(data[i].toString());",
    #   "}",
    #   "}"
    # )

  })


  output$table <- renderDT({
    req(!is.null(pulled()$ipsum))
    pulled <- pulled()
    ipsum <- pulled$ipsum
    filename = input$datafile$name
    datatable(ipsum,
              extensions = c("FixedHeader",'Buttons'),
              caption = paste("Using code from file ",filename),
              options = list(dom = 'BlfrtipB',
                             # paging=T,
                             buttons = c('copy', 'csv', 'excel', 'pdf', 'print'),
                             lengthMenu = list(c(10,25,50,-1),
                                               c(10,25,50,"All")))


             )
  })

  # tableone

  # trend plot
  trend <- reactive({
    start=year(input$dateRange[1])
    end=year(input$dateRange[2])
    # for OMOP
    if (input$Schema=='omop'){
      if (input$flag==T){
        outtab <- omopdata[input$Database==str_to_lower(Database) & year >= start & year <= end,]
        trend <- outtab[,':='(Total_patients=sum(Patients_OMOP),Total_records=sum(Records_OMOP)),by=c('year','category')] [,.(Database,year,category,Total_patients,Total_records)]
        setkey(trend,year,category)
      }
      else {
        outtab <- omopdata[year >= start & year <= end,]
        trend <- outtab[,':='(Total_patients=sum(Patients_OMOP),Total_records=sum(Records_OMOP)),by=c('Database','year','category')] [,.(Database,year,category,Total_patients,Total_records)]
        setkey(trend,year,category)

      }
      intlst <- c('Total_records','Total_patients')
      trendn <- trend[, (intlst) := lapply(.SD, as.numeric), .SDcols = intlst]
      return(trendn)
    }

    # Raw schema
    else  if (input$Schema == 'raw') {
      if (input$flag == T) {
        outtab <- rawdata[input$Database == str_to_lower(Database) & year >= start & year <= end,]
        trend <- outtab[,':='(Total_patients = sum(Patients_Raw),Total_records = sum(Records_Raw)),by = c('year','category')] [,.(Database,year,category,Total_patients,Total_records)]
        setkey(trend,year,category)
      }
      else {
        outtab <- rawdata[year >= start & year <= end,]
        trend <- outtab[,':='(Total_patients = sum(Patients_Raw),Total_records = sum(Records_Raw)),by = c('Database','year','category')] [,.(Database,year,category,Total_patients,Total_records)]
        setkey(trend,Database,year,category)
      }
      intlst <- c('Total_records','Total_patients')
      trendn <- trend[, (intlst) := lapply(.SD, as.numeric), .SDcols = intlst]
      return(trendn)
    }

  })


  output$trendplot <- renderPlotly({

    if (input$flag == T){

      # p <- ggplot(trend()) + geom_point(aes(x=year,y=Total_patients,color=category))
      trendplot <- trend() %>% group_by(category) %>% plot_ly(.,x=~year,y=~Total_patients,color=~category,type="scatter") %>%
        plotly::config(displaylogo=F,modeBarButtonsToRemove = list("sendDataToCloud","zoom2d","pan2d","select2d","lasso2d","zoomIn2d","zoomOut2d","toggleSpikelines"))

    }

    else {

      p <- ggplot(trend()) + geom_point(aes(x=year,y=Total_patients,color=category)) + facet_wrap(~Database)
      trendplot <- plotly::plotly_build(ggplotly(p)) %>% plotly::config(displaylogo=F,modeBarButtonsToRemove = list("sendDataToCloud","zoom2d","pan2d","select2d","lasso2d","zoomIn2d","zoomOut2d","toggleSpikelines"))

      # trendplot <- trend() %>% group_by(Database) %>% do(p=plot_ly(.,x=~year,y=~Total_patients,color=~category,type="scatter")) %>% subplot(nrows = 2,shareX=T,shareY = F) %>%
      #   plotly::config(displaylogo=F,modeBarButtonsToRemove = list("sendDataToCloud","zoom2d","pan2d","select2d","lasso2d","zoomIn2d","zoomOut2d","toggleSpikelines"))
      #

    }
    trendplot
  })


  # output$diagram <-
  #   DiagrammeR::renderDiagrammeR({
  #     DiagrammeR::mermaid(
  #       base::paste0(input$inText)
  #     )
  #   })
  library(DiagrammeR)
  output$diagram  <- renderDiagrammeR({
    req(!is.null(pulled()$attrition))
    attrit = setDT(pulled()$attrition)
    Nt=attrit[name == 'Total']$count
    Na=attrit[name == 'Age']$count
    Ns=attrit[name == 'Senio']$count
    Total = paste('Total inpatient cohort: ',Nt)
    Age = paste('Patients age >= 18: ',Na)
    Senior = paste('Patients age >= 65: ',Ns)
    ab = paste("A(",Total,")","-->","B(", Age,")")
    bc = paste("B(", Age,")","-->","C(", Senior,")")
    link = paste(ab,bc,sep = "\n")
    filename = input$datafile$name
    sub = paste("subgraph","Cohort for ",filename,".")
    # titles= title[<u>My Title</u>]
    # title-->FirstStep
    # style title fill:#FFF,stroke:#FFF
    #   linkStyle 0 stroke:#FFF,stroke-width:0;
    diagram <- paste("graph TB;",
                     sub,";"
                     ,
                     ab,";"
                     ,
                     bc,";",
                     "end"
    )
    mermaid(diagram)
  })

  # jscode = "window.open('','_parent','');window.close();"

  observeEvent(input$reset_input,
               {
                 shinyjs::reset('side_panel')
                 # reset('form')
               })

  observeEvent(input$toTop, {
    shinyjs::toggle("note")
  })

  observeEvent(input$close, {
    shinyjs::runjs("window.open('','_parent','');window.close();")
  })

  # adding additional tabs
  output$ui <- renderUI({

    check1 <- input$Tabs == "tabs"
    check2 <- input$MoreTabs == "moretabs"

    if (length(check1) == 0) {check1 <- F}
    if (length(check2) == 0) {check2 <- F}

    if (check1 && check2) {
      tabsetPanel(title = "intro",id = "ttabs", width = 8, height = "420px",
             tabPanel("Baseline summary", dataTableOutput("table")),
             tabPanel("Diagram", dataTableOutput("diagram"))
      )
    }
    else if (check1) {
      tabBox(title = "intro",id = "ttabs", width = 8, height = "420px",tabPanel("Baseline summary", dataTableOutput("table")))
    }
    else{return(NULL)}
  })

  # adding addtional detail summary for table 1 with p vlues
  # observeEvent(input$add, {
  #   insertUI(
  #     selector = "#add",
  #     where = "afterEnd",
  #     ui =  output$numvar
  #   )
  # })

  observeEvent(input$reset_output, {
    shinyjs::reset("main_panel")
    shinyjs::reset("forms")
  })


  output$numvar <- renderUI({
    pulled <- pulled()
    ipsamp <- pulled$ipsamp
    idlist <- scan(text = names(ipsamp),what = '',quiet = T)
    dfl <- ipsamp[,..idlist]
    nums <- sapply(dfl, is.numeric)
    items = names(nums[nums])
    selectInput("Num", "Continous variables:", items,multiple = T)
  })


  output$catvar <- renderUI({
    ipsamp <- pulled()$ipsamp
    idlist <- scan(text = names(ipsamp),what = '',quiet = T)
    dfl <- ipsamp[,..idlist]
    nums <- sapply(dfl, is.character)
    items = names(nums[nums])
    selectizeInput("char", "Categorical variables:",items,multiple = T)
  })

  # factor
  # if reactive is used below only the latest selection shows so has to be renderText
  fact <- renderText({
    req(input$char) # ensure availablity of value before proceeding
    factv <- vector()
    factlist <- paste(factv,input$char)
    return(factlist)
  })


  output$group <- renderUI({
    ipsamp <- pulled()$ipsamp
    #Let's only show columns with chr
    exc <- scan(text = fact(),what = '',quiet = T)
    dfl <- ipsamp[,.SD, .SDcols = !exc] # exclusion of those from factor
    nums <- sapply(dfl, is.character)
    filt <- lapply(dfl, function(x) length(unique(x)))
    filts <- filt <= 10
    items = names(nums[filts])
    # names(items)=items
    selectInput("group", "Group by:",items,multiple = F)
  })

  num <- renderText({
    req(input$Num) # ensure availability of value before proceeding
    numv <- vector()
    numlist <- paste0(numv,input$Num)
    return(numlist)
  })

  group <- reactive({
      req(input$group)
      grp <- input$group
      return(grp)
  })

 tablep <- reactive({
    ipsamp <- pulled()$ipsamp
    list <- reactive({paste(fact(),num(),group())})
  tablist <- reactive({paste(fact(),num())})
  tabvar <- scan(text = list(),what = "",quiet = T)
  library(gtsummary)
  tabone <- ipsamp %>% select(tabvar)
  tabonep <- tbl_summary(tabone,by = group()) %>% add_overall() %>% add_p(all_categorical() ~ 'chisq.test') %>% as_tibble()
  setDT(tabonep)
  })


 output$tablep <- renderDT({
   filename = input$datafile$name
   datatable(tablep(),
             extensions = c("FixedHeader",'Buttons'),
             caption = paste("Using code from file ",filename),
             options = list(dom = 'BlfrtipB',
                            # paging=T,
                            buttons = c('copy', 'csv', 'excel', 'pdf', 'print'),
                            lengthMenu = list(c(10,25,50,-1),
                                              c(10,25,50,"All")))


   )
 })

 observeEvent(input$adds, {
   insertTab(inputId = "main_panel",
             tabPanel("Customized summary", "Summary based on selection dynamically"),
             target = "diagram",
             output$tablep
   )
 })

 observeEvent(input$remove, {
   removeTab(inputId = "main_panel", target = "Customized summary")
 })

} #end of server

