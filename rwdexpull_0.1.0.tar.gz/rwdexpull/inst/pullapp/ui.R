lib <- list('shiny','shinyjs','DBI','data.table',
'DT','ggplot2','plotly','DiagrammeR')
lapply(lib,require,character.only = T)


ui <-  fluidPage(
    tags$head(HTML("<title>RWDEx cohort data explorer</title>")
              ),
    titlePanel(div(tags$img(width = 50,height = 50,src = "merck-co.jpg"),
                   "RWDEx cohort data explorer")
    ),
    p(),
    # for landing page
    tags$head(tags$style(HTML('
      .modal.in .modal-dialog{
        width:100%;
        height:100%;
        margin:0px auto;
        position: float;

      }
      .modal-content{
        width:100%;
        height:120%;
        margin:0% auto;
      }
      .close {
  color: #aaa;
  float: center;
  font-size: 28px;
  font-weight: bold;
}
    '))),
    # end of landing page   # background-color: #007a73;
    sidebarLayout(
      sidebarPanel(
        id = 'side_panel',
        uiOutput("fileflag"),
        p(),
        #Selector for file upload
        conditionalPanel(condition = "input.fileflag==true",
                         div(style = "height:18px; font-size:17px;bold;color:#007a73;",
                             icon('paperclip'),'File uploading:'),
                         fileInput('datafile', 'Please select file with ICD codes(CSV/TXT):',
                                   accept = c('text/csv', 'text/comma-separated-values,text/plain'))
                         ,
                         uiOutput("basic"),

        )
        ,
        uiOutput("pull"),
        p(),

        conditionalPanel(condition = "input.pullflag == true",
                         div(style = "height:18px; font-size:17px;bold;color:#007a73;",
                             icon('vcard'),'Credential to RWDEx')
                         ,
                         passwordInput("user", "Redshift user:"),
                         passwordInput("password", "Redshift password:")
        )
        ,

        div(style = "height:18px; font-size:17px;bold;color:#007a73;",icon('gauge'),"Parameters:"),
        p(),
        dateRangeInput('dateRange',
                       # icon('calendar')
                       # ,
                       label = 'Filter by date'
                       ,
                       start = '2016-01-01',
                       end = '2022-12-31',
                       min = '2016-01-01',
                       max = '2022-12-31'
                       )
          ,

        p(),

        uiOutput("regflag"),
        p(),

        uiOutput("flag"),

        p(),

        conditionalPanel(condition="input.flag == true",
                         div(style = "height:17px; font-size:17px;bold;color:#007a73;",
                             icon('briefcase'),'Available Databases:'),
                         uiOutput('aflag')
        )
        ,
        p(),

        div(style = "height:17px; font-size:17px;bold;color:#007a73;" ,icon('refresh'),"Options:"
         ),
        uiOutput("add"),
        p()
        ,
        conditionalPanel(
          condition = "input.add == true",
          uiOutput("numvar"),
          uiOutput("catvar"),
          uiOutput("group"),
          actionButton("adds", "Show customized")
        ),

        # actionButton("remove", "Remove customized"),
        actionButton('reset_input','Reset selection')
        #  ,
        # actionButton('reset_output','Reset results')
        ,

        p(),
        # useShinyjs(),
        # extendShinyjs("shinyjs.toTop = function() {document.body.scrollTop = 0;}"),
        # div(style = "height:15px; font-size:15px;bold;color:#007a73;","Note:",
        #     icon('files'),
        #
        # actionButton("toTop", "Hidden Notes to Users"),
        # div(id = "note",
        #     "This app is designed for explonatory analysis.
        #     If you would like to pull data by yourself please
        #     make sure you have get access previledge assigned to you.")
        # ),
        p(),

        # shinyjs::useShinyjs(),
        # actionButton("close", "Close app")
        #     ,

        # uiOutput("ids"),
        #
        # p(),
        #
        # uiOutput("bees"),
        p()
      )
      ,
      mainPanel(
        tabsetPanel(
          # shinyjs::useShinyjs(),
          # id = 'main_panel',
          tabPanel(tags$em(icon('binoculars'),'Uploaded file preview',
                           style = 'color:navy;'
                           # ,
                           # tags$style("#print {color: gold;
                           #  font-size: 15px;
                           #  bold;
                           # font-style: italic;
                           # }")
          ),
          dataTableOutput("print")

          )
          ,
          tabPanel(tags$em(icon('vials'),"Cohort sample",style="color: navy;"),
                   p("Pulled cohort preview"),
                   dataTableOutput('pulled')
          ),
          tabPanel(tags$em(icon('book'),"Baseline summary",
                           style="color:navy;"
                         #   ,
                         #   tags$style("#print {color: black;
                         #     font-size: 10px;
                         # font-style: italic;
                         # }")
                           ),
                   p("Downloadable table."),
                   # textOutput("summ"),
                   DTOutput("table")
                   # gt_output("table")
                   # tableOutput("down")
          ),
          tabPanel(tags$em(icon('wand-magic-sparkles'),"Diagram",style="color: navy;"),
                   p("Attrition diagram"),
                   # dataTableOutput('comp')
                   DiagrammeR::DiagrammeROutput(outputId = "diagram", width = "1050px", height = "auto")
          )
           ,
          # conditionalPanel(condition = "input.add == true",
                             tabPanel(tags$em(icon('image'),"Customized summary",style = "color:navy;"),
                             p("Customized data summary"),
                             dataTableOutput('tablep')
                             )

          # , # end of customized table,
          # conditionalPanel(condition = "input.add == true",
          #                  tags$em(icon('image'),"Customized",style = "color:navy;"),
          #                  tabPanel(
          #                    p("Customized summary with p"),
          #                    dataTableOutput('tablep')
          #                  )
          #
          # ) # end of customized table
        ) # end of Tabsetpanel

      ) # end of mainPanel
    ) # end of sidebarlayout

  ) # Endo of fluidpage

